<?php

namespace App\Http\Controllers\Api;
use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\students;
use DB;

class StudentController extends Controller
{
   public function index(Request $request)
   {
     $students=students::all();
     $data=[
'status'=>200,
'students'=>$students
     ];
     return response()->json($data,200);
   }
   public function store(Request $request){
    $student=students::create([
        'name'=>$request->name,
        'email'=>$request->email,
        'mobile'=>$request->mobile

    ]);
    if($student){
      return response()->json([
             'status'=>200,
             'message'=>"Student Created successfully"
      ],200);
    }else{

        return response()->json([
            'status'=>500,
            'message'=>"Something went wrong"
        ],500);

    }
   }

   public function update(Request $request){
     $student = students::find($request->id);


    if($student){


        $student->name = $request->name;
        $student->email = $request->email;
        $student->mobile = $request->mobile;

        // Save the changes
        $student->save();

     return response()->json([
            'status' => 200,
            'message' => "Student updated successfully"
        ], 200);
    }else{

        return response()->json([
            'status'=>500,
            'message'=>"Something went wrong"
        ],500);

    }
   }


public function view(Request $request){
    
    $student = students::find($request->id); 

    if($student){
        return response()->json([
            'status' => 200,
            'message' => "Student found successfully",
            'data' => $student  
        ], 200);
    } else {
       
        return response()->json([
            'status' => 404,
            'message' => "Student not found"
        ], 404);
    }
}


public function remove(Request $request){
    $student = students::find($request->id);



    if($student){
        $student->delete();

        return response()->json([
            'status' => 200,
            'message' => "Student removed successfully"
        ], 200);
    }else{

        return response()->json([
            'status'=>500,
            'message'=>"Something went wrong"
        ],500);

    }
   }




}
